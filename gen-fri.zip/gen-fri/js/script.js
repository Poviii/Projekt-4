document.addEventListener("DOMContentLoaded", () => {
  // === BURGER MENU TOGGLE ===
  const burgerBtn = document.getElementById("burger-btn");
  const sidebar = document.getElementById("sidebar");

  if (burgerBtn && sidebar) {
    burgerBtn.addEventListener("click", () => {
      const icon = burgerBtn.querySelector("img");
      const isVisible = sidebar.classList.toggle("sidebar--visible");

      if (isVisible) {
        icon.src = "icons/black_icons/circle-xmark.svg";
        icon.alt = "Close Menu";
      } else {
        icon.src = "icons/black_icons/burgermenu_black.svg";
        icon.alt = "Menu";
      }
    });
  }

  // === DARK MODE TOGGLE ===
  const themeToggle = document.getElementById("theme-toggle");
  const root = document.documentElement;

  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const currentTheme = root.getAttribute("data-theme");
      const newTheme = currentTheme === "dark" ? "light" : "dark";
      root.setAttribute("data-theme", newTheme);
    });
  }

  // === TABS + INDICATOR ===
  const tabs = document.querySelectorAll(".main-content__tab");
  const tabContents = document.querySelectorAll("[data-tab-content]");
  const tabIndicator = document.querySelector(".main-content__tab-indicator");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("main-content__tab--active"));
      tabContents.forEach((content) => (content.style.display = "none"));

      tab.classList.add("main-content__tab--active");
      const target = tab.getAttribute("data-tab");
      const activeContent = document.querySelector(`[data-tab-content="${target}"]`);
      if (activeContent) activeContent.style.display = "block";

      if (tabIndicator) {
        const tabRect = tab.getBoundingClientRect();
        const containerRect = tab.parentElement.getBoundingClientRect();
        tabIndicator.style.width = `${tabRect.width}px`;
        tabIndicator.style.transform = `translateX(${tabRect.left - containerRect.left}px)`;
      }

      // Accessibility
      tabs.forEach((t) => t.setAttribute("aria-selected", "false"));
      tab.setAttribute("aria-selected", "true");
      tab.parentElement?.setAttribute("data-active-tab", target);
    });
  });

  // Set initial indicator position
  const activeTab = document.querySelector(".main-content__tab--active");
  if (activeTab && tabIndicator) {
    const tabRect = activeTab.getBoundingClientRect();
    const containerRect = activeTab.parentElement.getBoundingClientRect();
    tabIndicator.style.width = `${tabRect.width}px`;
    tabIndicator.style.transform = `translateX(${tabRect.left - containerRect.left}px)`;
  }

  // === CAROUSEL ===
  const carouselContainer = document.querySelector(".event-carousel__container");
  const prevButton = document.querySelector(".event-carousel__prev");
  const nextButton = document.querySelector(".event-carousel__next");

  let scrollPosition = 0;

  if (carouselContainer && prevButton && nextButton) {
    const getBoxWidth = () => {
      const box = document.querySelector(".event-box");
      return box ? box.offsetWidth + 16 : 0;
    };

    prevButton.addEventListener("click", () => {
      scrollPosition = Math.min(scrollPosition + getBoxWidth(), 0);
      carouselContainer.style.transform = `translateX(${scrollPosition}px)`;
    });

    nextButton.addEventListener("click", () => {
      const maxScroll = -(carouselContainer.scrollWidth - carouselContainer.offsetWidth);
      scrollPosition = Math.max(scrollPosition - getBoxWidth(), maxScroll);
      carouselContainer.style.transform = `translateX(${scrollPosition}px)`;
    });
  }

  // === SCROLL TO TOP BUTTON ===
  const scrollUpBtn = document.getElementById("scrollUpBtn");
  if (scrollUpBtn) {
    window.addEventListener("scroll", () => {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        scrollUpBtn.style.display = "block";
      } else {
        scrollUpBtn.style.display = "none";
      }
    });

    scrollUpBtn.addEventListener("click", () => {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    });
  }
});
